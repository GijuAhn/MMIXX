# MMIXX

## 라이브러리

```bash
# react-router-dom ^6.9.0
npm install react-router-dom

# axios ^1.3.4
npm install axios

# @mui/icons-material ^5.11.11
npm install @mui/icons-material

# @mui/material
npm install @mui/material

# @mui/styled
npm install @mui/styled

# recoil ^0.7.7
npm install recoil

# aos ^2.3.4
npm install aos

# styled-components ^.5.3.9
npm install styled-components
```