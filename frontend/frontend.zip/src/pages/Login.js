const Login = () => {
    // window.location.href = "http://localhost:5555/api/user/login"; 
    window.location.href = "https://j8a403.p.ssafy.io/api/user/login"; 
};

export default Login;