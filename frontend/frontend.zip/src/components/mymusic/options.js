export const filterOptions = [
  ["all", "모든 음악"],
  ["mix", "믹스 음악"],
  ["origin", "원본 음악"],
];
export const orderOptions = [
  ["optgroup", "제목"],
  ["title1", "\u00a0\u00a0\u00a0\u00a0ㄱㄴㄷ순"],
  ["title2", "\u00a0\u00a0\u00a0\u00a0ㅎㅍㅌ순"],
  ["optgroup", "업로드 날짜"],
  ["date2", "\u00a0\u00a0\u00a0\u00a0최신순"],
  ["date1", "\u00a0\u00a0\u00a0\u00a0오래된 순"],
  ["optgroup", "곡 길이"],
  ["length1", "\u00a0\u00a0\u00a0\u00a0짧은 순"],
  ["length2", "\u00a0\u00a0\u00a0\u00a0긴 순"],
];
